/*
Issin Enta
AP CS
HW 21
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Life {

    private final int row;

    private final int column;
    private final int pixels;
    private boolean[][] board;
    private final String geometry;

    public static volatile int generation = 0;

    public Life(int row, int column, int pixels, String geometry) {
        this.row = row;
        this.column = column;
        this.pixels = pixels;
        this.geometry = geometry;
        this.board = new boolean[row][column];
    }

    public int getColumn() {
        return column;
    }

    public int getRow() {
        return row;
    }

    public boolean isInBounds(int row, int column) {
        return row < board.length && column < board[0].length;
    }

    public boolean isLive(int row, int column) {
        return board[row][column];
    }

    public void setLive(int row, int column) {
        board[row][column] = true;
    }

    public void setDead(int row, int column) {
        board[row][column] = false;
    }

    public void togglelife(int row, int column) {
        board[row][column] = !board[row][column];
    }

    public void next() {
        boolean[][] next = new boolean[row][column];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                int liveCount = checkSurrounding(i, j, geometry);
                if (liveCount == 3) {
                    next[i][j] = true;
                } else next[i][j] = liveCount == 2 && isLive(i, j);
            }
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                board[i][j] = next[i][j];
            }
        }
        generation++;
    }

    public int checkSurrounding(int row, int column, String geometry) {
        int liveCount = 0;
        int startRow = -1;
        int startColumn = -1;
        int endRow = 1;
        int endColumn = 1;
        if (geometry.equals("grid")) {
            if (row == 0) {
                startRow++;
            } else if (row == this.board.length - 1) {
                endRow--;
            }
            if (column == 0) {
                startColumn++;
            } else if (column == this.board[0].length - 1) {
                endColumn--;
            }
            for (int i = startRow; i <= endRow; i++) {
                for (int j = startColumn; j <= endColumn; j++) {
                    if (board[i + row][j + column]) {
                        liveCount++;
                    }
                }
            }
            if (board[row][column]) {
                liveCount--;
            }
        } else if (geometry.equals("rod")) {
            if (column == 0) {
                startColumn++;
            } else if (column == this.board[0].length - 1) {
                endColumn--;
            }
            for (int i = startRow; i <= endRow; i++) {
                for (int j = startColumn; j <= endColumn; j++) {
                    if (i + row == -1) {
                        if (board[board.length - 1][j + column]) {
                            liveCount++;
                        }
                    } else if (i + row == board.length) {
                        if (board[0][j + column]) {
                            liveCount++;
                        }
                    } else {
                        if (board[i + row][j + column]) {
                            liveCount++;
                        }
                    }
                }
            }
            if (board[row][column]) {
                liveCount--;
            }
        } else if (geometry.equals("cylinder")) {
            if (row == 0) {
                startRow++;
            } else if (row == this.board.length - 1) {
                endRow--;
            }
            for (int i = startRow; i <= endRow; i++) {
                for (int j = startColumn; j <= endColumn; j++) {
                    if (j + column == -1) {
                        if (board[i + row][board[0].length - 1]) {
                            liveCount++;
                        }
                    } else if (j + column == board[0].length) {
                        if (board[i + row][0]) {
                            liveCount++;
                        }
                    } else {
                        if (board[i + row][j + column]) {
                            liveCount++;
                        }
                    }
                }
            }
            if (board[row][column]) {
                liveCount--;
            }
        } else if (geometry.equals("torus")) {
            for (int i = startRow; i <= endRow; i++) {
                for (int j = startColumn; j <= endColumn; j++) {
                    boolean rowStart = i + row == -1;
                    boolean colStart = j + column == -1;
                    boolean rowEnd = i + row == board.length;
                    boolean colEnd = j + column == board.length;
                    if (rowStart && colStart) {
                        if (board[board.length - 1][board[0].length - 1]) {
                            liveCount++;
                        }
                    } else if (rowEnd && colEnd) {
                        if (board[0][0]) {
                            liveCount++;
                        }
                    } else if (rowStart) {
                        if (colEnd) {
                            if (board[board.length - 1][0]) {
                                liveCount++;
                            }
                        } else {
                            if (board[board.length - 1][j + column]) {
                                liveCount++;
                            }
                        }
                    } else if (rowEnd) {
                        if (colStart) {
                            if (board[0][board[0].length - 1]) {
                                liveCount++;
                            }
                        } else {
                            if (board[0][j + column]) {
                                liveCount++;
                            }
                        }
                    } else if (colStart) {
                        if (board[i + row][board[0].length - 1]) {
                            liveCount++;
                        }
                    } else if (colEnd) {
                        if (board[i + row][0]) {
                            liveCount++;
                        }
                    } else {
                        if (board[i + row][j + column]) {
                            liveCount++;
                        }
                    }
                }
            }
            if (board[row][column]) {
                liveCount--;
            }
        }
        return liveCount;
    }

    public static int generation() {
        return generation;
    }

    public void read(File filename) throws FileNotFoundException {
        int row = 0;
        Scanner file = new Scanner(filename);
        while (file.hasNextLine()) {
            String line = file.nextLine();
            for (int col = 0; col < line.length(); col++) {
                if (col >= board[0].length) {
                    break;
                }
                if (line.charAt(col) == '*' || line.charAt(col) == 'O') {
                    setLive(row, col);
                }
            }
            row++;
            if (row >= board.length) {
                break;
            }
        }
    }

    public void print() {
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                if (board[i][j]) {
                    System.out.print('*');
                } else {
                    System.out.print('.');
                }
            }
            System.out.println();
        }
    }

    public void center() {
        int startRow = Integer.MAX_VALUE;
        int startCol = Integer.MAX_VALUE;
        int endRow = 0;
        int endCol = 0;
        int rowChange;
        int colChange;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j]) {
                    if (i < startRow) {
                        startRow = i;
                    } else if (j < startCol) {
                        startCol = j;
                    }
                }
            }
        }
        for (int i = board.length - 1; i > 0; i--) {
            for (int j = board[0].length - 1; j > 0; j--) {
                if (board[i][j]) {
                    if (i > endRow) {
                        endRow = i;
                    } else if (j > endCol) {
                        endCol = j;
                    }
                }
            }
        }
        rowChange = ((board.length - (endRow - startRow)) / 2) - startRow;
        colChange = ((board[0].length - (endCol - startCol)) / 2) - startCol;

        boolean[][] temp = new boolean[board.length][board[0].length];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j]) {
                    temp[i + rowChange][j + colChange] = board[i][j];
                }
            }
        }
        board = temp;
    }

    public void paint(SimpleGUI.Canvas canvas) {
        canvas.clear();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j]) {
                    canvas.fill(i * pixels, i * pixels + pixels - 1, j * pixels, j * pixels + pixels - 1);
                }
            }
        }
    }
}