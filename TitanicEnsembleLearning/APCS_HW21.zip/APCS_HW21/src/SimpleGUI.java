/*
Issin Enta
AP CS
HW 21
 */
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleGUI {

    private JButton runStopButton;
    private static JSlider speedSlider;
    public volatile boolean stopped = true;
    private final JFrame frame;
    private final CanvasPanel canvasPanel;
    private JLabel generationNum;
    private Life life;
    private Canvas canvas;

    public SimpleGUI(int width, int height, Canvas canvas, Life life) {
        this.life=life;
        this.canvas=canvas;
        this.frame = new JFrame("Homework 21: Isshin Enta");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.canvasPanel = new CanvasPanel(canvas);

        JPanel labelPanel = new JPanel();

        this.generationNum = new JLabel();
        generationNum.setText("Generation: 0");
        labelPanel.add(generationNum);

        JPanel ButtonPanel= new JPanel();
        this.runStopButton = new RunButton(this,"Run");
        ButtonPanel.add(runStopButton);

        JButton step = new StepButton(this, "Step");
        ButtonPanel.add(step);

        JPanel SliderPanel = new JPanel();
        this.speedSlider = new SpeedSlider(0,100,50);
        SliderPanel.add(speedSlider);

        JPanel contentPanel = new JPanel();
        ButtonPanel.setLayout(new BoxLayout(ButtonPanel,BoxLayout.X_AXIS));
        contentPanel.setPreferredSize(new Dimension(canvas.columns(), canvas.rows()));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.add(canvasPanel);
        contentPanel.add(labelPanel);
        contentPanel.add(ButtonPanel);
        contentPanel.add(SliderPanel);

        Container content = frame.getContentPane();
        content.add(contentPanel);
        this.frame.pack();
        this.frame.setVisible(true);
    }

    private class RunButton extends JButton implements ActionListener {
        private final SimpleGUI gui;

        public RunButton(SimpleGUI gui, String label) {
            super(label);
            this.addActionListener(this);
            this.gui = gui;
        }

        @Override
        public void actionPerformed(ActionEvent event) {
            if(getText().equals("Run")){
                stopped=false;
                this.setText("Stop");
            }
            else{
                stopped=true;
                this.setText("Run");
            }
            this.gui.redraw();
        }
    }

    private class SpeedSlider extends JSlider implements ChangeListener {
        public SpeedSlider(int low, int high, int initial){
            super(low,high,initial);
            this.addChangeListener(this);
        }

        @Override
        public void stateChanged(ChangeEvent event) {
            double value = SimpleGUI.speedSlider.getValue() * 3 / 100;
            Homework_21.speed = (int) Math.pow(10, value);
        }
    }
    private class StepButton extends JButton implements ActionListener {
        private final SimpleGUI gui;

        public StepButton(SimpleGUI gui, String label) {
            super(label);
            this.addActionListener(this);
            this.gui = gui;
        }

        @Override
        public void actionPerformed(ActionEvent event) {
            if (runStopButton.getText().equals("Stop")) {
                stopped=true;
                runStopButton.setText("Run");
            }
            life.next();
            life.paint(canvas);
            this.gui.redraw();
        }
    }

    public static void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
        }
    }

    public void redraw() {
        this.frame.repaint();
    }

    public class CanvasPanel extends JPanel {

        private final Canvas canvas;

        public CanvasPanel(Canvas canvas) {
            super();
            this.canvas = canvas;
            int height = canvas.rows();
            int width = canvas.columns();
            setPreferredSize(new Dimension(width, height));
        }

        public Canvas getCanvas() {
            return this.canvas;
        }

        @Override
        public void paint(Graphics graphics) {

            int rows = this.canvas.rows();
            int columns = this.canvas.columns();

            for (int row = 0; row < rows; row++) {
                for (int column = 0; column < columns; column++) {
                    Color color = this.canvas.isSet(row, column) ? Color.BLACK : Color.WHITE;
                    graphics.setColor(color);
                    graphics.fillRect(column, row, 1, 1);
                }
            }
            generationNum.setText("Generation: " + Life.generation());
        }
    }

    public static class Canvas {

        private int rows;
        private int columns;
        private boolean[][] canvas;

        public Canvas(int rows, int columns) {
            this.rows = rows;
            this.columns = columns;
            this.canvas = new boolean[rows][columns];
        }

        public int rows() {
            return this.rows;
        }

        public int columns() {
            return this.columns;
        }

        public boolean isOnCanvas(int row, int column) {
            return (row >= 0 && row < this.rows) &&
                    (column >= 0 && column < this.columns);
        }

        public boolean isSet(int row, int column) {
            return isOnCanvas(row, column) && this.canvas[row][column];
        }

        public void set(int row, int column, boolean value) {
            if (isOnCanvas(row, column)) {
                this.canvas[row][column] = value;
            }
        }

        public void set(int row, int column) {
            set(row, column, true);
        }

        public void clear(int row, int column) {
            set(row, column, false);
        }

        public void clear() {
            for (int row = 0; row < this.rows; row++) {
                for (int column = 0; column < this.columns; column++) {
                    this.canvas[row][column] = false;
                }
            }
        }

        public void fill(int bottom, int top, int left, int right, boolean value) {
            // Fills a rectangle with given cooredinates for top and bottom
            // rows and for left and right columns.
            for (int row = bottom; row <= top; row++) {
                for (int column = left; column <= right; column++) {
                    set(row, column, value);
                }
            }
        }

        public void fill(int bottom, int top, int left, int right) {
            fill(bottom, top, left, right, true);
        }

        public void clear(int bottom, int top, int left, int right) {
            fill(bottom, top, left, right, false);
        }

        @Override
        public String toString() {
            // Produces an image of the canvas that can be printed on System.out.
            String result = "";
            for (int row = 0; row < this.rows; row++) {
                for (int column = 0; column < this.columns; column++) {
                    result += isSet(row, column) ? "*" : ".";
                }
                result += "\n";
            }
            return result;
        }

        public boolean equals(Canvas other) {
            // Check that two canvas' have the same contents.
            for (int row = 0; row < this.rows; row++) {
                for (int column = 0; column < this.columns; column++) {
                    if (this.canvas[row][column] != other.canvas[row][column]) {
                        return false;
                    }
                }
            }
            return true;
        }

        public boolean equals(Object other) {
            return other instanceof Canvas && this.equals((Canvas) other);
        }
    }

}
