/*
Issin Enta
AP CS
HW 21
 */
import java.io.File;
import java.io.FileNotFoundException;

public class Homework_21 {
    public static volatile int speed=10;
    public static void main(String[] args) throws FileNotFoundException {
        int rows = 100;
        int columns = 100;
        int generations = Integer.MAX_VALUE;
        int pixels = 5;
        String shape = "grid";
        boolean center = false;
        String filename = null;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-rows")) {
                rows = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-columns")) {
                columns = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-size")) {
                rows = Integer.parseInt(args[i + 1]);
                columns = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-generations")) {
                generations = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-pixels")) {
                pixels = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-speed")) {
                speed = Integer.parseInt(args[i + 1]);
                i++;
            } else if (args[i].equals("-center")) {
                center = true;
            } else if (args[i].equals("-grid")) {
                shape = "grid";
            }else if (args[i].equals("-rod")) {
                shape = "rod";
            }else if (args[i].equals("-cylinder")) {
                shape = "cylinder";
            }else if (args[i].equals("-torus")) {
                shape = "torus";
            }
            else {
                filename = args[i];
            }
        }
        Life life = new Life(rows, columns,pixels,shape);
        try {
            life.read(new File(filename));
        }
        catch (NullPointerException e){
            System.out.println("No input file: " + e.getMessage());
        }

        if(center){
            life.center();
        }
        SimpleGUI.Canvas canvas = new SimpleGUI.Canvas(rows*pixels,columns*pixels);
        life.paint(canvas);
        SimpleGUI gui = new SimpleGUI(rows,columns,canvas,life);
        while(life.generation()<generations) {
            if(!gui.stopped) {
                life.next();
                life.paint(canvas);
                gui.redraw();
                gui.sleep(1000 / speed);
            }
        }
    }
}
