//Viresh Pati
//Mr. Paige
//Artificial Intelligence
//Sliding Tile Puzzle
//September 10, 2022

public enum Direction {
    RIGHT,
    DOWN,
    LEFT,
    UP
}
